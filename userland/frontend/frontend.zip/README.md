# react-flow-demo-app

基于 `React Flow` 构建流程图，可拖拽添加节点，并通过 `useContext` 实现了简易的状态管理

文章地址：[https://www.cnblogs.com/wisewrong/p/15638354.html](https://www.cnblogs.com/wisewrong/p/15638354.html)

<br />



### 启动项目

```
yarn & yarn start
```



请在src/Toolbar/index.jsx中 修改api server的url
